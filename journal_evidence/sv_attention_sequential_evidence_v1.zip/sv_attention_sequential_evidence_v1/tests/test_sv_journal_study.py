"""Scientific audit checks: identify corrupt states and keep failed attempts."""
import numpy as np
import pytest

from cp_svm import FastOneClassSVM
from journal_studies.sv_attention.run_study import run_trajectory, self_check, summarize
from journal_studies.sv_attention import guarded_solver
from journal_studies.sv_attention.guarded_solver import CheckedRefitError, GuardedSVDD, checked_refit


def test_self_check_detects_stationarity_error_despite_feasible_coefficients():
    X = np.random.default_rng(99).normal(size=(24, 6))
    model = FastOneClassSVM(C=1 / (0.4 * len(X))).seed_from_qp(X)
    assert self_check(model, X)["passed"]
    model.rho += 0.1
    diagnosis = self_check(model, X)
    assert diagnosis["mass_error"] < 1e-5
    assert diagnosis["box_violation"] < 1e-5
    assert diagnosis["stationarity_violation"] > 0.09
    assert not diagnosis["passed"]


def test_failed_update_is_preserved_separately_from_successful_refit(monkeypatch):
    original = FastOneClassSVM.remove_point
    calls = 0

    def fail_first(self, index):
        nonlocal calls
        calls += 1
        if calls == 1:
            raise RuntimeError("injected pre-mutation failure")
        return original(self, index)

    monkeypatch.setattr(FastOneClassSVM, "remove_point", fail_first)
    trajectory = run_trajectory("gaussian", 24, 6, 40998, 2)
    assert trajectory["status"] == "completed"
    first = trajectory["operations"][0]
    assert first["fallback"]
    assert first["raw"] is None
    assert first["raw_self_check"]["reason"] == "shape_mismatch"
    assert "injected" in first["update_error"]
    assert first["post"]["gate_score_max_abs"] < 1e-10
    result = summarize([trajectory])
    assert result["fallbacks"] == 1
    assert result["operations_attempted"] == result["operations_scheduled"] == 4
    assert result["raw"]["unavailable_comparisons"] == 1
    assert result["post"]["comparison_count"] == 4


def test_trajectory_reproducible_inputs_and_fixed_cap():
    first = run_trajectory("gaussian", 24, 6, 40997, 2)
    second = run_trajectory("gaussian", 24, 6, 40997, 2)
    assert first["status"] == second["status"] == "completed"
    assert len(first["operations"]) == len(second["operations"]) == 4
    assert first["input_sha256"] == second["input_sha256"]
    assert first["C"] == second["C"] == 1 / (0.4 * 24)
    for left, right in zip(first["operations"], second["operations"]):
        assert left["retained_capacity"] >= 1
        assert left["raw"] == right["raw"]
        assert left["post"] == right["post"]


def test_guard_accepts_valid_candidate_and_returns_state_copies():
    X = np.random.default_rng(40999).normal(size=(24, 6))
    guarded = GuardedSVDD(C=1 / (0.4 * len(X))).seed_from_qp(X)
    guarded.remove_point(4)
    assert guarded.last_operation["accepted"]
    assert not guarded.last_operation["fallback"]
    assert self_check(guarded, np.delete(X, 4, axis=0))["passed"]
    exposed = guarded.alpha
    exposed[:] = -1
    assert np.min(guarded.alpha) >= -1e-5


def test_guard_replaces_infeasible_candidate_without_publishing_it(monkeypatch):
    X = np.random.default_rng(40996).normal(size=(24, 6))
    guarded = GuardedSVDD(C=1 / (0.4 * len(X))).seed_from_qp(X)
    original_remove = FastOneClassSVM.remove_point

    def corrupt(self, index):
        original_remove(self, index)
        self.alpha[0] = -0.1

    monkeypatch.setattr(FastOneClassSVM, "remove_point", corrupt)
    guarded.remove_point(3)
    expected = np.delete(X, 3, axis=0)
    assert guarded.last_operation["fallback"]
    assert not guarded.last_operation["raw_self_check"]["passed"]
    assert guarded._last_raw.alpha[0] < 0
    assert self_check(guarded, expected)["passed"]
    reference, _ = checked_refit(expected, guarded.C, guarded.kpar)
    np.testing.assert_allclose(guarded.decision_function(expected), reference.decision_function(expected), atol=1e-12)


def test_guard_rolls_back_when_all_rescues_fail(monkeypatch):
    X = np.random.default_rng(40995).normal(size=(24, 6))
    guarded = GuardedSVDD(C=1 / (0.4 * len(X))).seed_from_qp(X)
    before = guarded.alpha, guarded.X, guarded.rho, guarded.decision_function(X)

    def broken_update(self, index):
        self.alpha[:] = -1
        raise RuntimeError("injected interrupted mutation")

    def no_rescue(*args, **kwargs):
        raise CheckedRefitError([{"accepted": False, "error": "injected QP failure"}])

    monkeypatch.setattr(FastOneClassSVM, "remove_point", broken_update)
    monkeypatch.setattr(guarded_solver, "checked_refit", no_rescue)
    with pytest.raises(CheckedRefitError):
        guarded.remove_point(3)
    assert not guarded.last_operation["accepted"]
    np.testing.assert_array_equal(guarded.alpha, before[0])
    np.testing.assert_array_equal(guarded.X, before[1])
    assert guarded.rho == before[2]
    np.testing.assert_array_equal(guarded.decision_function(X), before[3])


def test_strict_refit_resolves_original_seed_stationarity_case():
    rng = np.random.default_rng(np.random.SeedSequence([41003, 64, 64, 0]))
    X = rng.normal(size=(64, 64))
    C, sigma = 1 / (0.4 * 64), 2 * np.sqrt(64 / 6)
    original = FastOneClassSVM(C=C, kpar=sigma).seed_from_qp(X)
    assert not self_check(original, X)["passed"]
    strict, attempts = checked_refit(X, C, sigma)
    assert self_check(strict, X)["passed"]
    assert attempts[-1]["accepted"]


def test_guard_refuses_infeasible_fixed_cap_delete_with_empty_margin():
    X = np.random.default_rng(40994).normal(size=(4, 3))
    guarded = GuardedSVDD(C=0.25).seed_from_qp(X)
    assert self_check(guarded, X)["passed"]
    before = guarded.alpha.copy()
    with pytest.raises(CheckedRefitError):
        guarded.remove_point(1)
    assert not guarded.last_operation["accepted"]
    np.testing.assert_array_equal(guarded.X, X)
    np.testing.assert_array_equal(guarded.alpha, before)
