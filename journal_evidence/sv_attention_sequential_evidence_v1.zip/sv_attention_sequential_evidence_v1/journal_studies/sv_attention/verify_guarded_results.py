"""Offline integrity/count checks and compact summary, without solver calls."""
from collections import Counter
import hashlib
import json
from pathlib import Path


def main():
    here = Path(__file__).resolve().parent
    root = here.parents[1]
    original = json.loads((here / "results.json").read_text())
    guarded = json.loads((here / "guarded_results.json").read_text())
    lookup = {(t["regime"], t["n"], t["d"], t["seed"]): t for t in guarded["trajectories"]}
    completed = [t for t in original["trajectories"] if t["status"] == "completed"]
    assert all(t["input_sha256"] == lookup[(t["regime"], t["n"], t["d"], t["seed"])]["input_sha256"] for t in completed)
    rows = [r for t in guarded["trajectories"] for r in t["operations"]]
    assert len(guarded["trajectories"]) == 80 and len(rows) == 5120
    assert all(len(t["operations"]) == 64 and t["status"] == "completed" for t in guarded["trajectories"])
    assert all(r["post_self_check"]["passed"] and r["reference_self_check"]["passed"] and r["transaction"]["accepted"] for r in rows)
    for name, expected in guarded["code_sha256"].items():
        assert hashlib.sha256((root / name).read_bytes()).hexdigest() == expected, name
    for name, expected in original["code_sha256"].items():
        if name.startswith("cp_svm/"):
            assert guarded["code_sha256"][name] == expected, name
    attempts = [a for r in rows for a in r["reference_attempts"] + r["transaction"]["rescue_attempts"]] + [a for t in guarded["trajectories"] for a in t["seed_record"]["rescue_attempts"]]
    checks = {
        "original_completed_trajectory_input_hash_matches": len(completed),
        "guarded_trajectories": 80, "guarded_operations": 5120,
        "all_published_and_reference_states_pass_original_check": True,
        "core_solver_hashes_unchanged": True,
        "QP_status_counts": dict(Counter(a["status"] for a in attempts)),
        "QP_warning_counts": dict(Counter(w for a in attempts for w in a.get("warnings", []))),
        "guarded_results_sha256": hashlib.sha256((here / "guarded_results.json").read_bytes()).hexdigest(),
        "followup_protocol_sha256": guarded["followup_protocol_sha256"],
        "verification_code_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    (here / "guarded_verification.json").write_text(json.dumps(checks, indent=2) + "\n")
    summary = {k: v for k, v in guarded.items() if k != "trajectories"}
    summary["verification"] = checks
    (here / "guarded_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(checks, indent=2))


if __name__ == "__main__":
    main()
