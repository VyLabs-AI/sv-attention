"""Offline diagnostics for the frozen study; never re-runs or changes its data."""
from collections import Counter
import hashlib
import json
from pathlib import Path

from journal_studies.sv_attention.run_study import distribution


def main():
    here = Path(__file__).resolve().parent
    result_path = here / "results.json"
    report = json.loads(result_path.read_text())
    trajectories = report["trajectories"]
    rows = [row for trajectory in trajectories for row in trajectory["operations"]]
    assert len(trajectories) == 80
    assert sum(t["scheduled_operations"] for t in trajectories) == 5120
    assert len(rows) == report["summary"]["operations_attempted"]
    for trajectory in trajectories:
        assert trajectory["C"] == 1 / (0.4 * trajectory["n"])
        assert [row["ordinal"] for row in trajectory["operations"]] == list(range(1, len(trajectory["operations"]) + 1))
        assert trajectory["status"] != "completed" or len(trajectory["operations"]) == 64
    diagnostics = {
        "results_sha256": hashlib.sha256(result_path.read_bytes()).hexdigest(),
        "analysis_code_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "interpretation": "All-result summaries remain in results.json; valid-pair summaries below are conditional diagnostics and exclude neither failures nor denominators from the main report.",
        "raw_failure_reasons": {key: sum(r["raw_self_check"].get(key, 0) > 1e-5 for r in rows) for key in ("mass_error", "box_violation", "stationarity_violation")},
        "fallback_by_operation": dict(Counter(r["operation"] for r in rows if r["fallback"])),
        "warning_counts": dict(Counter(w for r in rows for k in ("update_warnings", "reference_warnings", "fallback_warnings") for w in r[k])),
        "seed_kkt_residual": distribution([t["seed_self_check"]["kkt_max"] for t in trajectories if "seed_self_check" in t]),
        "raw_kkt_residual": distribution([r["raw_self_check"].get("kkt_max") for r in rows]),
        "reference_kkt_residual": distribution([r["reference_self_check"].get("kkt_max") for r in rows if r["reference_self_check"]]),
        "post_kkt_residual": distribution([r["post_self_check"].get("kkt_max") for r in rows if r["post_self_check"]]),
        "paired_valid": {},
        "by_cycle": {},
        "worst_cases": {},
    }
    for phase in ("raw", "post"):
        valid = [r for r in rows if r[f"{phase}_self_check"]["passed"] and r["reference_self_check"]["passed"]]
        diagnostics["paired_valid"][phase] = {
            "count": len(valid), "out_of_attempted": len(rows),
            "gate_score_max_abs": distribution([r[phase]["gate_score_max_abs"] for r in valid]),
            "readout_value_range_fraction": distribution([r[phase]["readout_value_range_fraction"] for r in valid]),
            "readout_reference_range_fraction": distribution([r[phase]["readout_reference_range_fraction"] for r in valid]),
        }
        for metric in ("gate_score_max_abs", "readout_value_range_fraction"):
            trajectory, row = max(((t, r) for t in trajectories for r in t["operations"]), key=lambda tr: tr[1][phase][metric])
            diagnostics["worst_cases"][f"{phase}_{metric}"] = {
                "trajectory": {key: trajectory[key] for key in ("regime", "n", "d", "seed", "C", "sigma", "input_sha256")},
                "operation": row,
            }
    for cycle in range(1, 33):
        subset = [r for r in rows if r["cycle"] == cycle]
        diagnostics["by_cycle"][str(cycle)] = {
            "attempted_operations": len(subset),
            "fallbacks": sum(r["fallback"] for r in subset),
            "raw_gate_score_max_abs": distribution([r["raw"]["gate_score_max_abs"] for r in subset]),
            "post_gate_score_max_abs": distribution([r["post"]["gate_score_max_abs"] for r in subset]),
        }
    (here / "diagnostics.json").write_text(json.dumps(diagnostics, indent=2, allow_nan=False) + "\n")
    print(json.dumps({key: value for key, value in diagnostics.items() if key not in ("by_cycle", "worst_cases")}, indent=2))


if __name__ == "__main__":
    main()
