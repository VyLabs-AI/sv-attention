"""Transactional wrapper around the unchanged maintained SVDD implementation.

This wrapper validates numerical states. It does not repair the raw active-set
algorithm or make its tolerances into a proof of exact arithmetic equality.
"""
from __future__ import annotations

import copy
import time
import warnings

import cvxpy as cp
import numpy as np

from cp_svm import FastOneClassSVM
from cp_svm.kernels import radial_kernel
from cp_svm.oneclass_qp import partition_sets
from journal_studies.sv_attention.run_study import self_check

PARTITION_TOLERANCE = 1e-7
STATE_TOLERANCE = 1e-5
REFIT_TOLERANCES = (1e-12, 1e-13)


class CheckedRefitError(RuntimeError):
    """All declared rescue attempts failed; no unchecked state is published."""

    def __init__(self, attempts):
        super().__init__("No refit passed the unchanged numerical state check")
        self.attempts = attempts


def minimax_rho(K, alpha, C):
    """Minimize the maximum KKT stationarity violation at fixed alpha."""
    target = np.diag(K) - 2 * (K @ alpha)
    lower = alpha <= PARTITION_TOLERANCE
    upper = alpha >= C - PARTITION_TOLERANCE
    margin = ~(lower | upper)
    lo = float(np.max(target[lower | margin], initial=-np.inf))
    hi = float(np.min(target[upper | margin], initial=np.inf))
    if np.isfinite(lo) and np.isfinite(hi):
        value = (lo + hi) / 2
    elif np.isfinite(lo):
        value = lo
    elif np.isfinite(hi):
        value = hi
    else:
        value = 0.0
    return value, {
        "lower": lo if np.isfinite(lo) else None,
        "upper": hi if np.isfinite(hi) else None,
        "minimum_stationarity_residual": max(0.0, (lo - hi) / 2),
        "interval_feasible_at_state_tolerance": bool(lo - STATE_TOLERANCE <= hi + STATE_TOLERANCE),
    }


def checked_refit(X, C, sigma):
    """Two predeclared strict QP attempts, accepted only by recomputed KKT."""
    X = np.atleast_2d(np.asarray(X, dtype=np.float64))
    attempts = []
    if len(X) * C < 1 - 1e-12:
        raise CheckedRefitError([{"error": "fixed_cap_infeasible", "nC": float(len(X) * C)}])
    for tolerance in REFIT_TOLERANCES:
        start = time.perf_counter_ns()
        attempt = {"qp_tolerance": tolerance}
        try:
            K = radial_kernel(X, X, sigma)
            alpha = cp.Variable(len(X))
            constraints = [cp.sum(alpha) == 1, alpha >= 0, alpha <= C]
            problem = cp.Problem(cp.Minimize(cp.quad_form(alpha, cp.psd_wrap((K + K.T) / 2)) - np.diag(K) @ alpha), constraints)
            with warnings.catch_warnings(record=True) as seen:
                warnings.simplefilter("always")
                problem.solve(solver=cp.CLARABEL, tol_gap_abs=tolerance, tol_gap_rel=tolerance,
                              tol_feas=tolerance, tol_infeas_abs=tolerance, tol_infeas_rel=tolerance,
                              max_iter=1000)
            attempt["warnings"] = [str(w.message) for w in seen]
            attempt["status"] = problem.status
            if alpha.value is None:
                raise RuntimeError("QP returned no coefficients")
            a = np.asarray(alpha.value, dtype=np.float64).ravel()
            if not np.all(np.isfinite(a)):
                raise RuntimeError("QP returned nonfinite coefficients")
            # No clipping, snapping, projection, or normalization of coefficients.
            model = FastOneClassSVM(C=C, kpar=sigma)
            model.X, model.alpha, model._K = X.copy(), a.copy(), K.copy()
            model.S, model.E, model.R = partition_sets(a, C, tol=PARTITION_TOLERANCE)
            model._refactor()
            attempt["mean_rho_before_correction"] = float(model.rho)
            model.rho, attempt["offset_interval"] = minimax_rho(K, a, C)
            model._recompute_grad()
            attempt["corrected_rho"] = model.rho
            attempt["equality_dual"] = float(constraints[0].dual_value)
            attempt["lower_duals"] = np.asarray(constraints[1].dual_value).ravel().tolist()
            attempt["upper_duals"] = np.asarray(constraints[2].dual_value).ravel().tolist()
            attempt["objective"] = float(a @ K @ a - np.diag(K) @ a)
            attempt["self_check"] = self_check(model, X)
            attempt["accepted"] = bool(attempt["self_check"]["passed"])
            attempt["elapsed_ms"] = (time.perf_counter_ns() - start) / 1e6
            attempts.append(attempt)
            if attempt["accepted"]:
                return model, attempts
        except Exception as error:
            attempt.update(error=f"{type(error).__name__}: {error}", accepted=False,
                           elapsed_ms=(time.perf_counter_ns() - start) / 1e6)
            attempts.append(attempt)
    raise CheckedRefitError(attempts)


class GuardedSVDD:
    """A single-writer add/remove API that retains the last checked state.

    Raw candidates are available privately for the scientific audit, but are
    never used by public readouts. Read-only state access returns copies.
    """

    def __init__(self, C, kpar=2.0):
        self.C, self.kpar = float(C), float(kpar)
        self._model = None
        self._last_raw = None
        self.last_operation = None

    @property
    def X(self):
        return self._model.X.copy()

    @property
    def alpha(self):
        return self._model.alpha.copy()

    @property
    def rho(self):
        return self._model.rho

    @property
    def S(self):
        return list(self._model.S)

    @property
    def E(self):
        return list(self._model.E)

    @property
    def R(self):
        return list(self._model.R)

    def decision_function(self, Xq):
        return self._model.decision_function(Xq)

    def seed_from_qp(self, X):
        self._execute("seed", np.atleast_2d(np.asarray(X, dtype=np.float64)))
        return self

    def add_point(self, x_new):
        x = np.atleast_2d(np.asarray(x_new, dtype=np.float64))
        if x.shape != (1, self._model.X.shape[1]):
            raise ValueError("Admission must contain exactly one key of the established dimension")
        self._execute("admit", np.vstack([self._model.X, x]), x=x[0])
        return len(self._model.X) - 1

    def remove_point(self, index):
        if not isinstance(index, (int, np.integer)) or not 0 <= index < len(self._model.X):
            raise ValueError("Deletion index is outside the current state")
        self._execute("delete", np.delete(self._model.X, index, axis=0), index=int(index))

    def _execute(self, operation, expected_X, index=None, x=None):
        start = time.perf_counter_ns()
        record = {"operation": operation, "accepted": False, "fallback": False,
                  "raw_error": None, "rescue_attempts": []}
        # Copying is inside the measured transaction and isolates unsafe mutation.
        copy_start = time.perf_counter_ns()
        candidate = copy.deepcopy(self._model) if self._model is not None else FastOneClassSVM(C=self.C, kpar=self.kpar)
        record["copy_ms"] = (time.perf_counter_ns() - copy_start) / 1e6
        update_start = time.perf_counter_ns()
        try:
            if operation == "seed":
                candidate = FastOneClassSVM(C=self.C, kpar=self.kpar).seed_from_qp(expected_X)
            elif operation == "delete":
                candidate.remove_point(index)
            else:
                candidate.add_point(x)
        except Exception as error:
            record["raw_error"] = f"{type(error).__name__}: {error}"
        record["raw_update_ms"] = (time.perf_counter_ns() - update_start) / 1e6
        self._last_raw = candidate
        check_start = time.perf_counter_ns()
        record["raw_self_check"] = self_check(candidate, expected_X)
        record["validation_ms"] = (time.perf_counter_ns() - check_start) / 1e6
        if record["raw_error"] or not record["raw_self_check"]["passed"]:
            record["fallback"] = True
            try:
                candidate, record["rescue_attempts"] = checked_refit(expected_X, self.C, self.kpar)
            except CheckedRefitError as error:
                record["rescue_attempts"] = error.attempts
                record["total_ms"] = (time.perf_counter_ns() - start) / 1e6
                self.last_operation = record
                raise
        self._model = candidate
        record["accepted"] = True
        record["post_self_check"] = self_check(self._model, expected_X)
        record["total_ms"] = (time.perf_counter_ns() - start) / 1e6
        self.last_operation = record
