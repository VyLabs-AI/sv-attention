"""Frozen sequential fixed-C audit; new results only, never rewrites paper evidence."""
from __future__ import annotations

import argparse
from collections import Counter
from contextlib import redirect_stdout
from datetime import datetime, timezone
import hashlib
import io
import itertools
import json
import os
from pathlib import Path
import platform
import sys
import time
import warnings

import cvxpy
import numpy as np
import scipy

from cp_svm import FastOneClassSVM
from cp_svm.kernels import radial_kernel

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def distribution(values):
    a = np.asarray([v for v in values if v is not None], dtype=float)
    if not len(a):
        return None
    return {"n": len(a), "median": float(np.median(a)),
            "p95": float(np.quantile(a, 0.95)), "worst": float(np.max(a))}


def self_check(model, expected_X, partition_tol=1e-7, tolerance=1e-5):
    """Recompute KKT from the actual iterate, without cached gradients/refit."""
    a = np.asarray(model.alpha)
    if a.shape != (len(expected_X),) or model.X.shape != expected_X.shape:
        return {"passed": False, "reason": "shape_mismatch"}
    if not np.array_equal(model.X, expected_X):
        return {"passed": False, "reason": "key_mismatch"}
    if not np.all(np.isfinite(a)) or not np.isfinite(model.rho):
        return {"passed": False, "reason": "nonfinite_state"}
    gram = radial_kernel(expected_X, expected_X, model.kpar)
    grad = model.rho - np.diag(gram) + 2.0 * (gram @ a)
    lower = a <= partition_tol
    upper = a >= model.C - partition_tol
    margin = ~(lower | upper)
    stationarity = max(float(np.max(np.abs(grad[margin]), initial=0)),
                       float(np.max(-grad[lower], initial=0)),
                       float(np.max(grad[upper], initial=0)))
    mass = abs(float(a.sum()) - 1.0)
    box = max(float(np.max(-a, initial=0)),
              float(np.max(a - model.C, initial=0)))
    kkt = max(stationarity, mass, box)
    return {"passed": bool(kkt <= tolerance), "kkt_max": kkt,
            "mass_error": mass, "box_violation": box,
            "stationarity_violation": stationarity}


def compare(candidate, reference, X, V, probes):
    """Raw readout differences remain visible even when objectives nearly tie."""
    if candidate.alpha.shape != reference.alpha.shape or not np.array_equal(candidate.X, X):
        return None
    a, b = candidate.alpha, reference.alpha
    kp = radial_kernel(probes, X, candidate.kpar)
    gram = radial_kernel(X, X, candidate.kpar)
    wa, wb = kp * a[None, :], kp * b[None, :]
    da, db = wa.sum(axis=1), wb.sum(axis=1)
    if not np.all(np.isfinite(da)) or not np.all(np.isfinite(db)) or min(da.min(), db.min()) <= 0:
        return None
    ra, rb = wa @ V / da[:, None], wb @ V / db[:, None]
    readout_abs = float(np.max(np.abs(ra - rb)))
    value_range = float(np.max(np.ptp(V, axis=0)))
    reference_readout_range = float(np.max(np.ptp(rb, axis=0)))
    objective_a = float(a @ gram @ a - np.diag(gram) @ a)
    objective_b = float(b @ gram @ b - np.diag(gram) @ b)
    metrics = {
        "alpha_max_abs": float(np.max(np.abs(a - b))),
        "gate_score_max_abs": float(np.max(np.abs(candidate.decision_function(probes) - reference.decision_function(probes)))),
        "readout_max_abs": readout_abs,
        "readout_value_range_fraction": readout_abs / max(value_range, 1e-300),
        "readout_reference_range_fraction": readout_abs / max(reference_readout_range, 1e-300),
        "minimum_readout_denominator": float(min(da.min(), db.min())),
        "objective_gap_abs": abs(objective_a - objective_b),
        "partition_match": all(set(getattr(candidate, p)) == set(getattr(reference, p)) for p in ("S", "E", "R")),
    }
    metrics["audit_flags_pass"] = bool(metrics["gate_score_max_abs"] <= 1e-3 and metrics["readout_value_range_fraction"] <= 0.02)
    return metrics if all(np.isfinite(v) for v in metrics.values()) else None


def timed(call):
    start = time.perf_counter_ns()
    try:
        with warnings.catch_warnings(record=True) as seen:
            warnings.simplefilter("always")
            result = call()
        return result, (time.perf_counter_ns() - start) / 1e6, None, [str(w.message) for w in seen]
    except Exception as exc:  # preserve every failure, including backend-specific errors
        return None, (time.perf_counter_ns() - start) / 1e6, f"{type(exc).__name__}: {exc}", []


def run_trajectory(regime, n, d, seed, cycles):
    rng = np.random.default_rng(np.random.SeedSequence([seed, n, d, int(regime == "redundant")]))
    value_rng = np.random.default_rng(np.random.SeedSequence([seed, n, d, 777]))
    probe_rng = np.random.default_rng(np.random.SeedSequence([seed, n, d, 888]))
    centers = rng.normal(0, 2, (8, d)) if regime == "redundant" else None

    def draw(count, random):
        if centers is None:
            return random.standard_normal((count, d))
        return centers[random.integers(8, size=count)] + 0.02 * random.standard_normal((count, d))

    X = draw(n, rng)
    V = value_rng.uniform(-1, 1, (n, 4))
    anchors = draw(32, probe_rng)
    C, sigma = 1 / (0.4 * n), 2 * np.sqrt(d / 6)
    inputs = hashlib.sha256(X.tobytes() + V.tobytes() + anchors.tobytes())
    trajectory = {"regime": regime, "n": n, "d": d, "seed": seed,
                  "C": C, "sigma": float(sigma), "scheduled_operations": cycles * 2,
                  "operations": [], "started_utc": utc_now()}

    def refit():
        return FastOneClassSVM(C=C, kpar=sigma).seed_from_qp(X)

    maintained, setup_ms, seed_error, seed_warnings = timed(refit)
    trajectory["setup_ms"] = setup_ms
    trajectory["seed_warnings"] = seed_warnings
    trajectory["seed_error"] = seed_error
    if maintained is None:
        trajectory.update(status="seed_failed", input_sha256=inputs.hexdigest())
        return trajectory
    trajectory["seed_self_check"] = self_check(maintained, X)
    if not trajectory["seed_self_check"]["passed"]:
        trajectory.update(status="seed_self_check_failed", input_sha256=inputs.hexdigest())
        return trajectory

    for cycle in range(cycles):
        for operation in ("delete", "admit"):
            row = {"cycle": cycle + 1, "operation": operation,
                   "ordinal": 2 * cycle + int(operation == "admit") + 1}
            before_guards = maintained.guard_events
            before_refactors = maintained.refactor_count
            if operation == "delete":
                victim = int(rng.integers(len(X)))
                changed = X[victim:victim + 1].copy()
                row["victim_index"] = victim
                row["active_deletion"] = victim in maintained.S or victim in maintained.E
                row["deleted_alpha"] = float(maintained.alpha[victim])
                X, V = np.delete(X, victim, axis=0), np.delete(V, victim, axis=0)
                change = lambda: maintained.remove_point(victim)
                inputs.update(np.asarray([victim], dtype=np.int64).tobytes())
            else:
                changed = draw(1, rng)
                admitted_value = value_rng.uniform(-1, 1, (1, 4))
                X, V = np.vstack([X, changed]), np.vstack([V, admitted_value])
                change = lambda: maintained.add_point(changed[0])
                inputs.update(changed.tobytes() + admitted_value.tobytes())
            probes = np.vstack([X, changed, anchors, X[:16] + 0.1 * probe_rng.standard_normal((16, d))])
            inputs.update(probes.tobytes())
            row["retained_capacity"] = float(len(X) * C)
            _, row["update_ms"], row["update_error"], row["update_warnings"] = timed(change)
            row["guard_events"] = maintained.guard_events - before_guards
            row["refactor_events"] = maintained.refactor_count - before_refactors
            row["raw_self_check"] = self_check(maintained, X)
            reference, row["reference_ms"], row["reference_error"], row["reference_warnings"] = timed(refit)
            row["reference_self_check"] = self_check(reference, X) if reference is not None else None
            row["raw"] = compare(maintained, reference, X, V, probes) if reference is not None else None
            row["fallback"] = bool(row["update_error"] or not row["raw_self_check"]["passed"])
            row["fallback_ms"] = 0.0
            row["fallback_error"] = None
            row["fallback_warnings"] = []
            if row["fallback"]:
                maintained, row["fallback_ms"], row["fallback_error"], row["fallback_warnings"] = timed(refit)
            row["post_self_check"] = self_check(maintained, X) if maintained is not None else None
            row["post"] = compare(maintained, reference, X, V, probes) if maintained is not None and reference is not None else None
            row["executed_maintenance_ms"] = row["update_ms"] + row["fallback_ms"]
            row["status"] = "completed" if row["post_self_check"] and row["post_self_check"]["passed"] else "maintenance_failed"
            trajectory["operations"].append(row)
            if row["status"] != "completed":
                trajectory.update(status="aborted", input_sha256=inputs.hexdigest(), finished_utc=utc_now())
                return trajectory
    trajectory.update(status="completed", input_sha256=inputs.hexdigest(), finished_utc=utc_now())
    return trajectory


def summarize(trajectories):
    rows = [r for t in trajectories for r in t["operations"]]
    summary = {
        "trajectories_scheduled": len(trajectories),
        "trajectory_status": dict(Counter(t["status"] for t in trajectories)),
        "operations_scheduled": sum(t["scheduled_operations"] for t in trajectories),
        "operations_attempted": len(rows),
        "operation_status": dict(Counter(r["status"] for r in rows)),
        "fallbacks": sum(r["fallback"] for r in rows),
        "update_exceptions": dict(Counter(r["update_error"] for r in rows if r["update_error"])),
        "raw_self_check_failures": sum(not r["raw_self_check"]["passed"] for r in rows),
        "reference_failures": sum(r["reference_self_check"] is None or not r["reference_self_check"]["passed"] for r in rows),
        "active_deletions": sum(r.get("active_deletion", False) for r in rows),
        "guard_events": sum(r["guard_events"] for r in rows),
        "refactor_events": sum(r["refactor_events"] for r in rows),
        "timing_note": "Descriptive shared-host CPU timings; order fixed update then reference, and GPU work may overlap. Not a publishable speedup estimate.",
    }
    summary["operations_not_run"] = summary["operations_scheduled"] - len(rows)
    for phase in ("raw", "post"):
        present = [r[phase] for r in rows if r[phase] is not None]
        summary[phase] = {
            "comparison_count": len(present),
            "unavailable_comparisons": len(rows) - len(present),
            "audit_flag_failures": sum(not p["audit_flags_pass"] for p in present),
            "partition_matches": sum(p["partition_match"] for p in present),
        }
        for metric in ("alpha_max_abs", "gate_score_max_abs", "readout_max_abs",
                       "readout_value_range_fraction", "readout_reference_range_fraction", "objective_gap_abs"):
            summary[phase][metric] = distribution([p[metric] for p in present])
        summary[phase]["trajectory_max_gate_score"] = distribution([
            max((r[phase]["gate_score_max_abs"] for r in t["operations"] if r[phase] is not None), default=None)
            for t in trajectories])
    for key in ("update_ms", "reference_ms", "executed_maintenance_ms"):
        summary[key] = distribution([r[key] for r in rows])
    return summary


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default=str(HERE / "results.json"))
    parser.add_argument("--smoke", action="store_true", help="separate two-cycle implementation check, excluded from frozen grid")
    args = parser.parse_args()
    output = Path(args.output)
    if output.exists():
        raise FileExistsError(f"Refusing to overwrite an existing run: {output}")
    protocol = json.loads((HERE / "protocol.json").read_text())
    for variable in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
        if os.environ.get(variable) != "1":
            raise RuntimeError(f"Set {variable}=1 before importing numerical libraries")
    config_text = io.StringIO()
    with redirect_stdout(config_text):
        np.show_config()
    report = {
        "started_utc": utc_now(), "protocol": protocol,
        "protocol_sha256": sha256(HERE / "protocol.json"),
        "code_sha256": {str(p.relative_to(ROOT)): sha256(p) for p in [Path(__file__).resolve(), ROOT / "cp_svm/oneclass_fast.py", ROOT / "cp_svm/oneclass_qp.py", ROOT / "cp_svm/kernels.py"]},
        "environment": {"python": sys.version, "executable": sys.executable,
                        "platform": platform.platform(), "machine": platform.machine(),
                        "numpy": np.__version__, "scipy": scipy.__version__, "cvxpy": cvxpy.__version__,
                        "installed_solvers": cvxpy.installed_solvers(), "numpy_config": config_text.getvalue(),
                        "thread_variables": {k: os.environ[k] for k in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "VECLIB_MAXIMUM_THREADS")}},
        "command_argv": sys.argv, "smoke_only": args.smoke, "trajectories": []}
    grid = list(itertools.product(protocol["regimes"], protocol["initial_sizes"], protocol["dimensions"], protocol["seeds"]))
    if args.smoke:
        grid = [(regime, 24, 6, 40999) for regime in protocol["regimes"]]
    for i, (regime, n, d, seed) in enumerate(grid):
        trajectory = run_trajectory(regime, n, d, seed, 2 if args.smoke else protocol["cycles"])
        report["trajectories"].append(trajectory)
        print(f"{i+1}/{len(grid)} {regime} n={n} d={d} seed={seed}: {trajectory['status']}; fallbacks={sum(r['fallback'] for r in trajectory['operations'])}", flush=True)
        output.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    report["summary"] = summarize(report["trajectories"])
    report["by_condition"] = {f"{regime}_n{n}_d{d}": summarize([t for t in report["trajectories"] if (t["regime"], t["n"], t["d"]) == (regime, n, d)])
                              for regime, n, d in sorted({(t["regime"], t["n"], t["d"]) for t in report["trajectories"]})}
    report["by_operation"] = {op: summarize([{**t, "scheduled_operations": t["scheduled_operations"] // 2, "operations": [r for r in t["operations"] if r["operation"] == op]} for t in report["trajectories"]]) for op in ("delete", "admit")}
    report["finished_utc"] = utc_now()
    output.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    print(json.dumps(report["summary"], indent=2), flush=True)


if __name__ == "__main__":
    main()
