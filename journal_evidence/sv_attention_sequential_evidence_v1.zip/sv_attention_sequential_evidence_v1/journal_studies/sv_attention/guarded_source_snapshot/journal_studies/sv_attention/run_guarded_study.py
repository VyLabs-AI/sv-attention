"""Frozen follow-up grid for a separately checked transactional wrapper."""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import itertools
import json
import os
from pathlib import Path
import platform
import sys
import time

import cvxpy
import numpy as np

from journal_studies.sv_attention.guarded_solver import CheckedRefitError, GuardedSVDD, checked_refit
from journal_studies.sv_attention.run_study import compare, distribution, self_check, sha256, utc_now

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def run_trajectory(regime, n, d, seed, cycles):
    # Generation is byte-for-byte the same sequence of RNG calls as the original
    # study. More operations can run when previously failed seeds are rescued.
    rng = np.random.default_rng(np.random.SeedSequence([seed, n, d, int(regime == "redundant")]))
    value_rng = np.random.default_rng(np.random.SeedSequence([seed, n, d, 777]))
    probe_rng = np.random.default_rng(np.random.SeedSequence([seed, n, d, 888]))
    centers = rng.normal(0, 2, (8, d)) if regime == "redundant" else None

    def draw(count, random):
        if centers is None:
            return random.standard_normal((count, d))
        return centers[random.integers(8, size=count)] + 0.02 * random.standard_normal((count, d))

    X, V = draw(n, rng), value_rng.uniform(-1, 1, (n, 4))
    anchors = draw(32, probe_rng)
    C, sigma = 1 / (0.4 * n), 2 * np.sqrt(d / 6)
    inputs = hashlib.sha256(X.tobytes() + V.tobytes() + anchors.tobytes())
    trajectory = {"regime": regime, "n": n, "d": d, "seed": seed, "C": C,
                  "sigma": float(sigma), "scheduled_operations": cycles * 2,
                  "operations": [], "started_utc": utc_now()}
    maintained = GuardedSVDD(C=C, kpar=sigma)
    try:
        maintained.seed_from_qp(X)
    except CheckedRefitError:
        trajectory.update(status="seed_failed", seed_record=maintained.last_operation,
                          input_sha256=inputs.hexdigest(), finished_utc=utc_now())
        return trajectory
    trajectory["seed_record"] = maintained.last_operation

    for cycle in range(cycles):
        for operation in ("delete", "admit"):
            row = {"cycle": cycle + 1, "operation": operation,
                   "ordinal": 2 * cycle + int(operation == "admit") + 1}
            if operation == "delete":
                victim = int(rng.integers(len(X)))
                changed = X[victim:victim + 1].copy()
                row.update(victim_index=victim, active_deletion=victim in maintained.S or victim in maintained.E,
                           deleted_alpha=float(maintained.alpha[victim]))
                X, V = np.delete(X, victim, axis=0), np.delete(V, victim, axis=0)
                change = lambda: maintained.remove_point(victim)
                inputs.update(np.asarray([victim], dtype=np.int64).tobytes())
            else:
                changed = draw(1, rng)
                admitted_value = value_rng.uniform(-1, 1, (1, 4))
                X, V = np.vstack([X, changed]), np.vstack([V, admitted_value])
                change = lambda: maintained.add_point(changed[0])
                inputs.update(changed.tobytes() + admitted_value.tobytes())
            probes = np.vstack([X, changed, anchors, X[:16] + 0.1 * probe_rng.standard_normal((16, d))])
            inputs.update(probes.tobytes())
            row["retained_capacity"] = float(len(X) * C)
            try:
                change()
            except CheckedRefitError:
                pass  # the transaction has kept the previous valid state
            row["transaction"] = maintained.last_operation
            reference_start = time.perf_counter_ns()
            try:
                reference, row["reference_attempts"] = checked_refit(X, C, sigma)
            except CheckedRefitError as error:
                reference = None
                row["reference_attempts"] = error.attempts
            row["reference_ms"] = (time.perf_counter_ns() - reference_start) / 1e6
            row["reference_self_check"] = self_check(reference, X) if reference is not None else None
            row["raw"] = compare(maintained._last_raw, reference, X, V, probes) if reference is not None else None
            row["post_self_check"] = self_check(maintained, X)
            row["post"] = compare(maintained, reference, X, V, probes) if reference is not None else None
            row["status"] = "completed" if row["transaction"]["accepted"] else "rejected"
            trajectory["operations"].append(row)
            if row["status"] == "rejected":
                trajectory.update(status="aborted", input_sha256=inputs.hexdigest(), finished_utc=utc_now())
                return trajectory
    trajectory.update(status="completed", input_sha256=inputs.hexdigest(), finished_utc=utc_now())
    return trajectory


def summarize(trajectories):
    rows = [r for t in trajectories for r in t["operations"]]
    transactions = [r["transaction"] for r in rows]
    seed_records = [t["seed_record"] for t in trajectories]
    summary = {
        "trajectories_scheduled": len(trajectories),
        "trajectory_status": dict(Counter(t["status"] for t in trajectories)),
        "operations_scheduled": sum(t["scheduled_operations"] for t in trajectories),
        "operations_attempted": len(rows),
        "operation_status": dict(Counter(r["status"] for r in rows)),
        "seed_fallbacks": sum(s["fallback"] for s in seed_records),
        "seed_rejections": sum(not s["accepted"] for s in seed_records),
        "fallbacks": sum(t["fallback"] for t in transactions),
        "fallback_by_operation": dict(Counter(t["operation"] for t in transactions if t["fallback"])),
        "raw_update_exceptions": dict(Counter(t["raw_error"] for t in transactions if t["raw_error"])),
        "raw_failure_reasons": {key: sum(t["raw_self_check"].get(key, 0) > 1e-5 for t in transactions) for key in ("mass_error", "box_violation", "stationarity_violation")},
        "reference_failures": sum(r["reference_self_check"] is None or not r["reference_self_check"]["passed"] for r in rows),
        "maintenance_refit_tier_counts": dict(Counter(str(a.get("qp_tolerance")) for t in transactions + seed_records for a in t["rescue_attempts"])),
        "reference_refit_tier_counts": dict(Counter(str(a.get("qp_tolerance")) for r in rows for a in r["reference_attempts"])),
        "failed_maintenance_refit_attempts": sum(not a["accepted"] for t in transactions + seed_records for a in t["rescue_attempts"]),
        "failed_reference_refit_attempts": sum(not a["accepted"] for r in rows for a in r["reference_attempts"]),
        "timing_note": "Complete copy/update/check/rescue transaction is included. Shared-host descriptive timings, not a speedup claim.",
    }
    summary["operations_not_run"] = summary["operations_scheduled"] - len(rows)
    for phase in ("raw", "post"):
        records = [r[phase] for r in rows if r[phase] is not None]
        summary[phase] = {"comparison_count": len(records), "unavailable_comparisons": len(rows) - len(records),
                          "audit_flag_failures": sum(not r["audit_flags_pass"] for r in records),
                          "partition_matches": sum(r["partition_match"] for r in records)}
        for metric in ("alpha_max_abs", "gate_score_max_abs", "readout_max_abs", "readout_value_range_fraction",
                       "readout_reference_range_fraction", "objective_gap_abs"):
            summary[phase][metric] = distribution([r[metric] for r in records])
        summary[phase]["trajectory_max_gate_score"] = distribution([max((r[phase]["gate_score_max_abs"] for r in t["operations"] if r[phase] is not None), default=None) for t in trajectories])
    for metric in ("copy_ms", "raw_update_ms", "validation_ms", "total_ms"):
        summary[metric] = distribution([t[metric] for t in transactions])
    summary["reference_ms"] = distribution([r["reference_ms"] for r in rows])
    summary["raw_kkt_residual"] = distribution([t["raw_self_check"].get("kkt_max") for t in transactions])
    summary["post_kkt_residual"] = distribution([r["post_self_check"].get("kkt_max") for r in rows])
    summary["reference_kkt_residual"] = distribution([r["reference_self_check"].get("kkt_max") for r in rows if r["reference_self_check"]])
    return summary


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default=str(HERE / "guarded_results.json"))
    parser.add_argument("--smoke", action="store_true")
    args = parser.parse_args()
    output = Path(args.output)
    if output.exists():
        raise FileExistsError(f"Refusing to overwrite: {output}")
    for var in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
        if os.environ.get(var) != "1":
            raise RuntimeError(f"Set {var}=1 before importing numerical libraries")
    original_protocol = json.loads((HERE / "protocol.json").read_text())
    followup_protocol = json.loads((HERE / "followup_protocol.json").read_text())
    assert sha256(HERE / "protocol.json") == followup_protocol["parent_protocol_sha256"]
    assert sha256(HERE / "results.json") == followup_protocol["parent_results_sha256"]
    source_paths = [Path(__file__).resolve(), HERE / "guarded_solver.py", HERE / "run_study.py", ROOT / "cp_svm/oneclass_fast.py", ROOT / "cp_svm/oneclass_qp.py", ROOT / "cp_svm/kernels.py"]
    report = {"started_utc": utc_now(), "followup_protocol": followup_protocol,
              "followup_protocol_sha256": sha256(HERE / "followup_protocol.json"),
              "original_grid_protocol": original_protocol,
              "code_sha256": {str(p.relative_to(ROOT)): sha256(p) for p in source_paths},
              "environment": {"python": sys.version, "executable": sys.executable, "platform": platform.platform(),
                              "numpy": np.__version__, "cvxpy": cvxpy.__version__,
                              "thread_variables": {v: os.environ[v] for v in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "VECLIB_MAXIMUM_THREADS")}},
              "command_argv": sys.argv, "smoke_only": args.smoke, "trajectories": []}
    grid = list(itertools.product(original_protocol["regimes"], original_protocol["initial_sizes"], original_protocol["dimensions"], original_protocol["seeds"]))
    if args.smoke:
        grid = [(regime, 24, 6, 40999) for regime in original_protocol["regimes"]]
    for i, (regime, n, d, seed) in enumerate(grid):
        t = run_trajectory(regime, n, d, seed, 2 if args.smoke else original_protocol["cycles"])
        report["trajectories"].append(t)
        print(f"{i+1}/{len(grid)} {regime} n={n} d={d} seed={seed}: {t['status']}, seed_rescue={t['seed_record']['fallback']}, update_rescues={sum(r['transaction']['fallback'] for r in t['operations'])}", flush=True)
        output.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    report["summary"] = summarize(report["trajectories"])
    report["by_condition"] = {f"{regime}_n{n}_d{d}": summarize([t for t in report["trajectories"] if (t["regime"], t["n"], t["d"]) == (regime, n, d)]) for regime, n, d in sorted({(t["regime"], t["n"], t["d"]) for t in report["trajectories"]})}
    report["finished_utc"] = utc_now()
    output.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    print(json.dumps(report["summary"], indent=2), flush=True)


if __name__ == "__main__":
    main()
