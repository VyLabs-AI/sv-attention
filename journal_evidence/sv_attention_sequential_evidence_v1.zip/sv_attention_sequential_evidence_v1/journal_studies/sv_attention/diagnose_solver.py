"""Exploratory diagnosis of predetermined failures, separate from frozen audit."""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
import warnings

import cvxpy as cp
import numpy as np

from cp_svm import FastOneClassSVM
from cp_svm.kernels import radial_kernel
from cp_svm.oneclass_qp import partition_sets
from journal_studies.sv_attention import run_study


def offset_diagnosis(K, a, C, rho, partition_tolerance=1e-7):
    """Exact SVDD KKT signs, numerical partition fixed as in original audit."""
    target = np.diag(K) - 2 * (K @ a)
    lower = a <= partition_tolerance
    upper = a >= C - partition_tolerance
    margin = ~(lower | upper)
    lo = float(np.max(target[lower | margin], initial=-np.inf))
    hi = float(np.min(target[upper | margin], initial=np.inf))
    if np.isfinite(lo) and np.isfinite(hi):
        best = (lo + hi) / 2
    elif np.isfinite(lo):
        best = lo
    elif np.isfinite(hi):
        best = hi
    else:
        best = 0.0
    worst_index = int(np.argmax(np.where(margin, np.abs(rho - target), np.where(lower, np.maximum(target - rho, 0), np.maximum(rho - target, 0)))))
    return {
        "untoleranced_offset_lower": lo, "untoleranced_offset_upper": hi,
        "minimax_offset": best,
        "minimum_stationarity_residual": max(0.0, (lo - hi) / 2),
        "has_offset_at_original_tolerance": bool(lo - 1e-5 <= hi + 1e-5),
        "stored_offset": float(rho), "margin_count": int(margin.sum()),
        "worst_index": worst_index, "worst_alpha": float(a[worst_index]),
        "worst_distance_to_bound": float(min(abs(a[worst_index]), abs(C-a[worst_index]))),
    }


def direct_qp(X, C, sigma, tolerance):
    K = radial_kernel(X, X, sigma)
    a = cp.Variable(len(X))
    constraints = [cp.sum(a) == 1, a >= 0, a <= C]
    problem = cp.Problem(cp.Minimize(cp.quad_form(a, cp.psd_wrap((K + K.T) / 2)) - np.diag(K) @ a), constraints)
    with warnings.catch_warnings(record=True) as seen:
        warnings.simplefilter("always")
        problem.solve(solver=cp.CLARABEL, tol_gap_abs=tolerance, tol_gap_rel=tolerance,
                      tol_feas=tolerance, tol_infeas_abs=tolerance, tol_infeas_rel=tolerance,
                      max_iter=1000)
    if a.value is None:
        return {"status": problem.status}, None
    alpha = np.asarray(a.value).ravel()
    dual_rho = float(constraints[0].dual_value)
    diagnosis = offset_diagnosis(K, alpha, C, dual_rho)
    model = FastOneClassSVM(C=C, kpar=sigma)
    model.X, model.alpha, model._K = X.copy(), alpha.copy(), K.copy()
    model.S, model.E, model.R = partition_sets(alpha, C, tol=1e-7)
    model._refactor()
    mean_rho_check = run_study.self_check(model, X)
    model.rho = diagnosis["minimax_offset"]
    model._recompute_grad()
    best_check = run_study.self_check(model, X)
    return {"status": problem.status, "tolerance": tolerance,
            "warnings": [str(w.message) for w in seen],
            "objective": float(problem.value), "dual_rho": dual_rho,
            "offset_diagnosis": diagnosis,
            "mean_rho_check": mean_rho_check, "best_rho_check": best_check}, model


def capture(regime, n, d, seed, cycle, operation, phase):
    snapshots = []
    original_check = run_study.self_check
    original_apply = FastOneClassSVM._apply
    violations = []

    def check(model, X, **kwargs):
        result = original_check(model, X, **kwargs)
        snapshots.append((copy.deepcopy(model), X.copy(), result))
        return result

    def apply(model, c, step, beta0, beta_S, gamma, s_empty):
        before = model.alpha.copy()
        original_apply(model, c, step, beta0, beta_S, gamma, s_empty)
        violation = max(float(np.max(-model.alpha, initial=0)), float(np.max(model.alpha-model.C, initial=0)))
        if violation > 1e-5:
            affected = int(np.argmax(np.maximum(-model.alpha, model.alpha-model.C)))
            violations.append({"step": float(step), "changed_index": c,
                               "violating_index": affected, "before_alpha": float(before[affected]),
                               "after_alpha": float(model.alpha[affected]), "cap": model.C,
                               "box_violation": violation, "margin_count": len(model.S)})
    run_study.self_check = check
    FastOneClassSVM._apply = apply
    try:
        trajectory = run_study.run_trajectory(regime, n, d, seed, cycle or 1)
    finally:
        run_study.self_check = original_check
        FastOneClassSVM._apply = original_apply
    if phase == "seed":
        index = 0
    else:
        ordinal = 2 * (cycle - 1) + int(operation == "admit")
        index = 1 + ordinal * 3 + int(phase == "reference")
    model, X, check_result = snapshots[index]
    return model, X, check_result, trajectory, violations


def main():
    here = Path(__file__).resolve().parent
    cases = [
        ("worst_box", "redundant", 64, 6, 41005, 10, "delete", "raw"),
        ("worst_readout", "redundant", 64, 6, 41002, 2, "admit", "raw"),
        ("seed_stationarity", "gaussian", 64, 64, 41003, 0, None, "seed"),
        ("reference_stationarity", "gaussian", 64, 6, 41000, 15, "delete", "reference"),
    ]
    report = {"purpose": "Exploratory diagnosis of four predetermined original-study failures; not a new validation grid", "cases": {}}
    for name, regime, n, d, seed, cycle, operation, phase in cases:
        model, X, original, trajectory, violations = capture(regime, n, d, seed, cycle, operation, phase)
        K = radial_kernel(X, X, model.kpar)
        offset = offset_diagnosis(K, model.alpha, model.C, model.rho)
        changed = copy.deepcopy(model)
        changed.rho = offset["minimax_offset"]
        changed._recompute_grad()
        direct = []
        for tolerance in (1e-10, 1e-12, 1e-13):
            result, _ = direct_qp(X, model.C, model.kpar, tolerance)
            direct.append(result)
        report["cases"][name] = {
            "selection": {"regime": regime, "n": n, "d": d, "seed": seed,
                          "cycle": cycle, "operation": operation, "phase": phase},
            "input_sha256": hashlib.sha256(X.tobytes()).hexdigest(),
            "original_self_check": original,
            "offset_diagnosis": offset,
            "offset_only_self_check": run_study.self_check(changed, X),
            "direct_refits": direct,
            "observed_infeasible_steps": violations,
        }
        np.savez(here / f"diagnostic_{name}.npz", X=X, alpha=model.alpha, C=model.C, sigma=model.kpar, rho=model.rho)
        print(name, "original", original["kkt_max"], "best_offset", report["cases"][name]["offset_only_self_check"]["kkt_max"], "strict_refit", direct[1]["best_rho_check"]["kkt_max"], flush=True)
    report["analysis_code_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    (here / "solver_diagnosis.json").write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
