# SV Attention: sequential solver audit supplement

The original frozen audit and the separately frozen guarded follow-up are both
included, preserving failures. The original audit completed 66 of 80 trajectories
and attempted 4,390 of 5,120 scheduled operations. The guarded follow-up completed
80 trajectories and 5,120 operations, with 8 initialization rescues and 84 update
rescues. Numerical KKT acceptance used the original 1e-5 tolerance and 1e-7
partition convention. Strict refit and offset recovery are a wrapper around the
unchanged core solver, not a new exact-arithmetic proof or a silently repaired
version of the original measurements.

Both grids are synthetic Gaussian/near-duplicate fixed-C problems: n=64/128,
d=6/64, ten seeds, 32 delete/admit cycles. Independent current-state checks and
fresh QP comparisons do not establish exact numerical equality, universal future
cache-pruning safety, or real-model retained utility. The reference shares the
QP backend; readout deviations remain visible. Shared-host timings are
descriptive and do not establish a speed advantage.

`journal_studies/sv_attention/` contains protocols, results, diagnostics, guard
verification, and the executed runner/wrapper. Frozen snapshot copies preserve
their original layout. The three core solver modules match both measured hash
sets. Other cp_svm modules needed by its package initializer are copied from the
contemporaneous Gemma frozen snapshot; their status is identified in the manifest.
Test and diagnostic helpers are packaging-time copies with their own hashes.

## Recheck and reproduce

Python 3.11 was used. Recorded environment details (including numerical libraries
and thread variables) are embedded in both result JSON files. The measured
versions include NumPy 2.4.6, SciPy 1.17.1, CVXPY 1.9.2 and CLARABEL as the strict
QP solver; the supplement does not install dependencies automatically.

Run these from this extracted directory, using an environment with those numerical
dependencies. The first command only checks stored data; it rewrites the two
derived verification/summary JSON files in this copy, so first verify the manifest
and use a disposable extraction. It does not change results or rerun a solver.

```sh
python -m journal_studies.sv_attention.verify_guarded_results
```

For new numerical runs use new output names. The guarded runner deliberately
binds to the included original protocol and original result hash; do not replace
that parent result when replaying the follow-up.

```sh
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1
python -m journal_studies.sv_attention.run_study --output original_reproduction.json
python -m journal_studies.sv_attention.run_guarded_study --output guarded_reproduction.json
python -m pytest -q tests/test_sv_journal_study.py
```

`analyze_results.py` re-derives the original diagnostics and `diagnose_solver.py`
replays selected exploratory failures; both use fixed filenames and write derived
outputs in their own directory. Use a disposable copy. Neither diagnostic replaces
the all-attempt denominators in the frozen main result. Numerical and timing
results can vary across solver/library/platform versions.

## Integrity and provenance

From this extracted directory, run `python verify_bundle.py` (standard library only).
`MANIFEST.json` records the SHA256, byte count, and original relative path of every
payload file. `MANIFEST.sha256` contains the same hashes in conventional format.
The manifests exclude themselves to avoid circular hashes; the ZIP has an external
SHA256 sidecar. Measured JSON and frozen code/protocols are copied byte for byte.
Absolute author-machine paths in original provenance are historical metadata, not
portable paths. New supporting files are explicitly marked in the manifest.

This is a supplement for the new journal studies, not a copy of all historical
experiments or the complete development repository. No model weights, dataset
source rows, private clinical data, cached conversations, generated responses,
token arrays from language-model corpora, credentials, or account files are
distributed. Synthetic solver inputs may be included. Existing source notices
remain in place; external models and datasets must be obtained under their own
access and license terms. The manifest and allowlist are an integrity/scope check,
not a claim of universal privacy or a new license grant.

The package is prepared locally for journal review. This does not establish a
public repository or DOI. Data-availability statements should say the supplement
provides the new studies' source-free measurements and analysis code, with
upstream data/models obtained separately; do not say all data or all historical
experiments are included or already publicly deposited.

## Existing license and attribution notices

`LICENSE` and `THIRD_PARTY_NOTICES.md` are copied unchanged from the original
SV Attention v2 source package. They preserve its Apache-2.0 terms and the
Cauwenberghs reference-implementation attribution/public-domain notice. That
original notice also names style files, datasets, and dependencies that are not
distributed in this supplement; their mention is not an inventory of this ZIP.
No original MATLAB source or fixtures are included.
